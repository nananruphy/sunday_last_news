package com.example.newnews;

import java.util.List;

public class News {
    private final String mTitle;
    private final String mTime;
    private final String mSectionName;
    private final String mUrl;
    private final List<String> mContributor;

    public News(String title,String time, String sectionName,String url,List<String> contributor){
        mTitle = title;
        mTime = time;
        mSectionName = sectionName;
        mUrl = url;
        mContributor = contributor;
    }

    public String getTitle(){return mTitle;}
    public String getTime(){return mTime;}
    public String getSectionName(){return mSectionName;}
    public String getUrl(){return mUrl;}
    public List<String> getContributor(){return mContributor;}
}