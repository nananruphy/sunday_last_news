package com.example.newnews;


import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.stream.Collectors;
import butterknife.BindView;
import butterknife.ButterKnife;

public class NewsAdapter extends ArrayAdapter<News> {
    ViewHolder holder;

    public NewsAdapter(Activity context, ArrayList<News> news){
        super(context,0,news);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        News currentInfo = getItem(position);

        String title = currentInfo.getTitle();
        String time = currentInfo.getTime();
        String sectionName = currentInfo.getSectionName();

        String timePart1 = time.substring(0,10);

        String timePart2 = time.substring(11,16);


        String timeDisplayed = timePart2 + "  "+ formatDate(timePart1);

        holder.sectionTextView.setText(sectionName);
        holder.titleTextView.setText(title);
        holder.timeTextView.setText(timeDisplayed);

        List<String> authorList = currentInfo.getContributor();

        String authorText = "";


        if (authorList.size() > 0) {
            for (String s: authorList){
                authorText += s + ", ";
            }
            int len = authorText.length();
            String newText = authorText.substring(0,len-2);
            holder.authorTextView.setText(newText);
        }
        else {
            holder.authorTextView.setVisibility(View.GONE);
        }
        return convertView;
    }

    static class ViewHolder{
        @BindView(R.id.section_name) TextView sectionTextView;
        @BindView(R.id.news_title) TextView titleTextView;
        @BindView(R.id.news_time) TextView timeTextView;
        @BindView(R.id.author_text) TextView authorTextView;

        public ViewHolder(View view) {
            ButterKnife.bind(this,view);
        }
    }
    private String formatDate(String dateStr) {
        DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
        DateFormat outputFormat = new SimpleDateFormat("MMM dd");
        Date date = null;
        try {
            date = inputFormat.parse(dateStr);
        } catch(ParseException e){
            e.printStackTrace();
        }
        String outputDate = outputFormat.format(date);
        return outputDate;
    }

}